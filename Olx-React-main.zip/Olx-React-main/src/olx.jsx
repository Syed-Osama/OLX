
import React from 'react'
// import './style.css'


import Olxnav from './components/olxNav'
import Olxfooter from './components/Olxfooter'
import OLXdashboard from './views/olxdashbaoard'
export default function olx() {
    return (
        <div>
            <Olxnav />

            <OLXdashboard />


            <Olxfooter />
        </div >


    )
}
